'use client'

import InputForm from "@/components/InputForm"

export default function Cal() {
    return (
    <>
    <h1>Calcunation</h1>
    <InputForm></InputForm>
    </>

)
}